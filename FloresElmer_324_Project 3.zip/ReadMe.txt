Author:Elmer Flores

Project 3 Knapsack Algo

This code grabs daata from the dat files. In the files the data of weight and price are added to arrays.
Then main method then calls the knapsack class, it checks to see if there is any null values. Then we create a table which shows
the rows as items and the columns as the price of the items.We then get the value of the item. Next step is to consider if we should pick
the element from the table or not. The following step is to see if that element is more profitable, we then can use the same information from our third for
loop to find out if it was picked or not. The last step is to return the items that were selected and also return the maximun profit.




All files included in my project are:

3 dat files that include the data for weights and prices  

FloresElmer_Knapsack

FloresElmer_KnapsackAlgo

output file that displays the most profitable price.

Readme file 
