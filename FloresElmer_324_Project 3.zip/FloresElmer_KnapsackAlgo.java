import java.util.*;
import java.lang.*;
import java.io.*;

class FloresElmer_KnapsackAlgo
{
	public static int knapsack(int capacity, int[] weight, int[] price) 
   {

    if (weight == null || price == null || weight.length != price.length || capacity < 0)
    {
      throw new IllegalArgumentException("No Values");
    }

   int total = weight.length;
    int[][] table = new int[total + 1][capacity + 1];

    for (int i = 1; i <= total; i++) 
      {

      int w = weight[i - 1], p = price[i - 1];

         for (int max = 1; max <= capacity; max++) 
         {

           table[i][max] = table[i - 1][max];
          
          
         
         if (max >= w && table[i - 1][max - w] + p > table[i][max]) 
         {
         table[i][max] = table[i - 1][max - w] + p;
         }
      }
    }

    int max = capacity;
    List<Integer> item = new ArrayList<>();


    for (int i = total; i > 0; i--) 
    {
         if (table[i][max] != table[i - 1][max]) 
          {
             int itemIndex = i - 1;
             item.add(itemIndex);
             max -= weight[itemIndex];
         }
    }

    System.out.println("The max profit is "+ table[total][capacity]);
    System.out.println(""); 
    return table[total][capacity];
  }
} 
