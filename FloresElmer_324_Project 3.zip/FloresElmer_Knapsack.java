import java.util.Scanner;
import java.io.*;
public class FloresElmer_Knapsack extends FloresElmer_KnapsackAlgo {
	
		public static void main(String[]args) throws Exception{
      int[] matrix = new int[5];
      int[] matrix2 = new int[5];
      int[] matrix3 = new int[5];
      
FloresElmer_Knapsack test1 = new FloresElmer_Knapsack();
FloresElmer_Knapsack test2 = new FloresElmer_Knapsack();
FloresElmer_Knapsack test3 = new FloresElmer_Knapsack();
               
         Scanner in;
try {
Scanner s = new Scanner(new File("Elmer_Knapsack.dat"));
Scanner t = new Scanner(new File("Elmer_Knapsack2.dat"));
Scanner r = new Scanner(new File("Elmer_Knapsack3.dat"));



      //test 1 from file
       for (int i = 0; i < matrix.length && s.hasNextLine(); i++) 
       {
          matrix[i]= s.nextInt() ;
          s.nextLine(); 
        }
          
        //test 2 from file       
        for (int i = 0; i < matrix2.length && t.hasNextLine(); i++) 
        {
          matrix2[i] = t.nextInt() ;
          t.nextLine(); 
         }
         
           //test 3 from file       
        for (int i = 0; i < matrix3.length && r.hasNextLine(); i++) 
        {
           matrix3[i] = r.nextInt() ;
          r.nextLine(); 
         }

                
                

            s.close();
            t.close();
            r.close();
            
        
        

        } catch (IOException i) {
            System.out.println("Problems..");

        }
 
   System.out.print("Test case one from the book:");       
   test1.knapsack(9, matrix2,matrix);
 
   System.out.print("Random test case two:"); 
   test2.knapsack(20, matrix2,matrix);
    
  
   System.out.print("Random test case three:"); 
    test3.knapsack(15,matrix,matrix3); 

       
        
 }
        
        
        
        
}
